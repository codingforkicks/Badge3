use [master]
GO

if exists (select * from sys.databases where name = N'HotelSimmons')
begin
	EXEC msdb.dbo.sp_delete_database_backuphistory @database_name = N'HotelSimmons';
	ALTER DATABASE HotelSimmons SET SINGLE_USER WITH ROLLBACK IMMEDIATE;
	DROP DATABASE HotelSimmons;
end

create database HotelSimmons
GO

use HotelSimmons
GO

-- tables
create table RoomType (
	RoomTypeId int primary key identity(1,1),
	BedType varchar(50) not null,
	StandardOccpancy int not null,
	MaxOccupancy int not null
)
GO

create table SuiteType (
	SuiteId int primary key identity(1,1),
	BedType varchar(50) not null,
	StandardOccpancy int not null,
	MaxOccupancy int not null
)
GO

create table Ammenities (
	AmenityId int primary key identity(1,1),
	AmenityType varchar(50),
    Fee bit not null
)
GO

create table Price (
	PriceId int primary key identity(1,1),
    BasePrice decimal(18,2) not null,
    ExtraPersonFee int
)
GO

create table RoomInfo (
    RoomNumber int primary key not null,
    Price int,
    AdaAccess char(3) not null
	constraint fk_RoomInfo_Price foreign key (Price)
        references Price(PriceId)
)
GO

create table Address (
	AddressId int primary key identity(1,1),
    City varchar(50),
	[State] varchar(2),
	ZipCode varchar(5)
)
GO

create table Contact (
    GuestId int primary key identity(101,1),
    FirstName varchar(50),
	LastName varchar(50),
	Address varchar(50),
	Address2 int,
	Phone char(14),
	Birthday char(8),
	constraint fk_Contact_Address2 foreign key (Address2)
        references Address(AddressId)
)
GO

create table Reservation (
    ReservationId uniqueidentifier primary key default(newsequentialid()),
	RoomId int,
	GuestId int,
	Adults int,
	Children int,
	TotalGuests int,
	StartDate date,
	EndDate date,
	RoomCost decimal(18,2),
	constraint fk_Reservation_GuestId foreign key (GuestId)
        references Contact(GuestId)
)
GO


-- join tables

create table RoomAmenities (
	RoomNumber int,
	AmenityId int,
    constraint fk_RoomInfo_RoomNumber foreign key (RoomNumber)
        references RoomInfo(RoomNumber),
	constraint fk_RoomAmenities_AmenityId foreign key (AmenityId)
        references Ammenities(AmenityId)
)
GO

create table GuestReservations (
	GuestId int,
	ReservationId uniqueidentifier,
    constraint fk_GuestReservations_GuestId foreign key (GuestId)
        references Contact(GuestId),
	constraint fk_GuestReservations_ReservationId foreign key (ReservationId)
        references Reservation(ReservationId)
)
GO


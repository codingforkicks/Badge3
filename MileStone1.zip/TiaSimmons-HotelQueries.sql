use HotelSimmons
GO
-- Write a query that returns a list of reservations that end in July 2023, including the name of the guest, the room number(s), and the reservation dates.
SELECT ReservationId, RoomId, StartDate, EndDate, FirstName, LastName
FROM Reservation r
LEFT OUTER JOIN Contact c 
	ON r.GuestId = c.GuestId
WHERE EndDate BETWEEN '2023-07-01' AND '2023-07-31';

-- Write a query that returns a list of all reservations for rooms with a jacuzzi, displaying the guest's name, the room number, and the dates of the reservation.
-- grabs all reservations with Jacuzzi rooms (could use subquery)
SELECT ReservationId, RoomId, StartDate, EndDate, FirstName, LastName, AmenityId
FROM Reservation r
RIGHT OUTER JOIN RoomAmenities a
	ON r.RoomId = a.RoomNumber
LEFT OUTER JOIN Contact c
	ON c.GuestId = r.GuestId
WHERE a.AmenityId = 2;

-- Write a query that returns all the rooms reserved for a specific guest, including the guest's name, the room(s) reserved, the starting date of the reservation, and how many people were included in the reservation. (Choose a guest's name from the existing data.)

SELECT ReservationId, RoomId, Adults, Children, StartDate, EndDate, RoomCost, FirstName, LastName
FROM Reservation r
LEFT OUTER JOIN Contact c 
	ON r.GuestId = c.GuestId
WHERE FirstName = 'Tia';

-- Write a query that returns a list of rooms, reservation ID, and per-room cost for each reservation. The results should include all rooms, whether or not there is a reservation associated with the room.
-- returns all rooms and prices
SELECT ReservationId, RoomNumber, RoomCost
FROM RoomInfo i
LEFT OUTER JOIN Reservation r
	ON i.RoomNumber = r.RoomId;

-- Write a query that returns all the rooms accommodating at least three guests and that are reserved on any date in April 2023.
-- returns none
SELECT *
FROM Reservation r
WHERE (TotalGuests > 2) AND ((StartDate LIKE '2023-04%') OR (EndDate LIKE '2023-04%'));


-- Write a query that returns a list of all guest names and the number of reservations per guest, sorted starting with the guest with the most reservations and then by the guest's last name.
-- returns reservations in decending order by amount and then my last name in alphabetical order
SELECT FirstName, LastName, COUNT(*) TotalReservations
FROM Reservation r
LEFT OUTER JOIN Contact c
	ON c.GuestId = r.GuestId
GROUP BY c.LastName, c.FirstName
ORDER BY TotalReservations DESC, c.LastName;

-- Write a query that displays the name, address, and phone number of a guest based on their phone number. (Choose a phone number from the existing data.)
SELECT FirstName, LastName, Address, City, State, ZipCode, Phone
FROM Contact c
LEFT OUTER JOIN Address a
	ON c.Address2 = a.AddressId
WHERE c.Phone LIKE '%08'
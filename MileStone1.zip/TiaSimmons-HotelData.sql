use HotelSimmons
GO

--Insert Data
SET IDENTITY_INSERT RoomType ON;
insert into RoomType (RoomTypeId, BedType, StandardOccpancy, MaxOccupancy) values
    (1, 'Single - 1 King Bed', 2, 2),
	(2, 'Double - 2 Queen Beds', 2, 4);
SET IDENTITY_INSERT RoomType OFF;

SET IDENTITY_INSERT SuiteType ON;
insert into SuiteType (SuiteId, BedType, StandardOccpancy, MaxOccupancy) values
    (1, 'Suite - 2 Queen Beds + 1 King Bed', 3, 8);
SET IDENTITY_INSERT SuiteType OFF;

SET IDENTITY_INSERT Ammenities ON;
insert into Ammenities (AmenityId, AmenityType, Fee) values
    (1, 'Microwave', 0),
	(2, 'Jacuzzi', 1),
	(3, 'Refrigerator', 0),
	(4, 'Oven', 0),
	(5, 'Kitchen', 0),
	(6, 'Living Room', 0),
	(7, 'Sleeper Sofa', 0);
SET IDENTITY_INSERT Ammenities OFF;

SET IDENTITY_INSERT Price ON;
insert into Price (PriceId, BasePrice, ExtraPersonFee) values
    (1, 149.99, 0),
	(2, 174.99, 10),
	(3, 199.99, 10),
	(4, 399.99, 20);
SET IDENTITY_INSERT Price OFF;
	
insert into RoomInfo (RoomNumber, Price, AdaAccess) values
    (201, 3, 'No'),
	(202, 2, 'Yes'),
	(203, 3, 'No'),
	(204, 2, 'Yes'),
	(205, 2, 'No'),
	(206, 1, 'Yes'),
	(207, 2, 'No'),
	(208, 1, 'Yes'),
	(301, 3, 'No'),
	(302, 2, 'Yes'),
	(303, 3, 'No'),
	(304, 2, 'Yes'),
	(305, 2, 'No'),
	(306, 1, 'Yes'),
	(307, 2, 'No'),
	(308, 1, 'Yes'),
	(401, 4, 'Yes'),
	(402, 4, 'Yes');

SET IDENTITY_INSERT Address ON;
insert into Address (AddressId, City, [State], ZipCode) values
    (1, 'Council Bluffs', 'IA', '51501'),
	(2, 'Wasilla', 'AK', '99654'),
	(3, 'Harlingen', 'TX', '78552'),
	(4, 'West Deptford', 'NJ', '08096'),
	(5, 'Saginaw', 'MI', '48601'),
	(6, 'Arvada', 'CO', '80003'),
	(7, 'Zion', 'IL', '60099'),
	(8, 'Cumberland', 'RI', '02864'),
	(9, 'Oswego', 'NY', '13126'),
	(10, 'Burke', 'VA', '22015'),
	(11, 'Drexel Hill', 'PA', '19026'),
	(12, 'None of Your Business', 'AR', '77605');
SET IDENTITY_INSERT Address OFF;

SET IDENTITY_INSERT Contact ON;
insert into Contact(GuestId, FirstName, LastName, Address, Address2, Phone, Birthday) values
    (1, 'Tia', 'Simmons', '379 Old Shore Street', 12, '(291)553-0508', null),
	(2, 'Mack', 'Simmer', '379 Old Shore Street', 1, '(291)553-0508', null),
	(3, 'Bettyann', 'Seery', '750 Wintergreen Dr.', 2, '(478) 277-9632', null),
	(4, 'Duane', 'Cullison', '9662 Foxrun Lane', 3, '(308) 494-0198', null),
	(5, 'Karie', 'Yang', '9378 W. Augusta Ave.', 4, '(214) 730-0298', null),
	(6, 'Aurore', 'Lipton', '762 Wild Rose Street', 5, '(377) 507-0974', null),
	(7, 'Zachery', 'Luechtefeld', '7 Poplar Dr.', 6, '(814) 485-2615', null),
	(8, 'Jeremiah', 'Pendergrass', '70 Oakwood St.', 7, '(279) 491-0960', null),
	(9, 'Walter', 'Holaway', '7556 Arrowhead St.', 8, '(446) 396-6785', null),
	(10, 'Wilfred', 'Vise', '77 West Surrey Street', 9, '(834) 727-1001', null),
	(11, 'Maritza', 'Tilton', '939 Linda Rd.', 10, '(446) 351-6860', null),
	(12, 'Joleen', 'Tison', '87 Queen St.', 11, '(231) 893-2755', null);
SET IDENTITY_INSERT Contact OFF;

insert into Reservation (ReservationId, RoomId, GuestId, Adults, Children, TotalGuests, StartDate, EndDate, RoomCost) values
    (NEWID(), 308, 2, 1, 0, 1, '2023-02-02', '2023-02-04', 299.98),
	(NEWID(), 203, 3, 2, 1, 3, '2023-02-05', '2023-02-10', 999.95),
	(NEWID(), 305, 4, 2, 0, 2, '2023-02-22', '2023-02-24', 349.98),
	(NEWID(), 201, 5, 2, 2, 4, '2023-03-06', '2023-03-07', 199.99),
	--Tia Simmons Entry
	(NEWID(), 307, 1, 1, 1, 2, '2023-03-17', '2023-03-20', 524.97),
	(NEWID(), 302, 6, 3, 0, 3, '2023-03-18', '2023-03-23', 924.95),
	(NEWID(), 202, 7, 2, 2, 4, '2023-03-29', '2023-03-31', 349.98),
	(NEWID(), 304, 8, 2, 0, 2, '2023-03-31', '2023-04-05', 874.95),
	(NEWID(), 301, 9, 1, 0, 1, '2023-04-09', '2023-04-13', 799.96),
	(NEWID(), 207, 10, 1, 1, 2, '2023-04-23', '2023-04-24', 174.99),
	(NEWID(), 401, 11, 2, 4, 6, '2023-05-30', '2023-06-02', 1199.97),
	(NEWID(), 206, 12, 2, 0, 2, '2023-06-10', '2023-06-14', 599.96),
	(NEWID(), 208, 12, 1, 0, 1, '2023-06-10', '2023-06-14', 599.96),
	(NEWID(), 304, 6, 3, 0, 3, '2023-06-17', '2023-06-18', 184.99),
	--Tia Simmons Entry
	(NEWID(), 205, 1, 2, 0,	2, '2023-06-28', '2023-07-02', 699.96),
	(NEWID(), 204, 9, 3, 1,	4, '2023-07-13', '2023-07-14', 184.99),
	(NEWID(), 401, 10, 4, 2, 6, '2023-07-18', '2023-07-21', 1259.97),
	(NEWID(), 303, 3, 2, 1,	3, '2023-07-28', '2023-07-29', 199.99),
	(NEWID(), 305, 3, 1, 0,	1, '2023-08-30', '2023-09-01', 349.98),
	(NEWID(), 208, 2, 2, 0,	2, '2023-09-16', '2023-09-17', 149.99),
	(NEWID(), 203, 5, 2, 2,	4, '2023-09-13', '2023-09-15', 399.98),
	(NEWID(), 401, 4, 2, 2,	4, '2023-11-22', '2023-11-25', 1199.97),
	(NEWID(), 206, 2, 2, 0,	2, '2023-11-22', '2023-11-25', 449.97),
	(NEWID(), 301, 2, 2, 2,	4, '2023-11-22', '2023-11-25', 599.97),
	(NEWID(), 302, 11, 2, 0, 2, '2023-12-24', '2023-12-28', 699.96);
	
insert into RoomAmenities (RoomNumber, AmenityId) values
    (201, 1),
	(201, 2),
	(202, 3),
	(203, 1),
	(203, 2),
	(204, 3),
	(205, 1),
	(205, 3),
	(205, 2),
	(206, 1),
	(206, 3),
	(207, 1),
	(207, 3),
	(207, 2),
	(208, 1),
	(208, 3),
	(301, 1),
	(301, 2),
	(302, 3),
	(303, 1),
	(303, 2),
	(304, 3),
	(305, 1),
	(305, 3),
	(305, 2),
	(306, 1),
	(306, 3),
	(307, 1),
	(307, 3),
	(307, 2),
	(308, 1),
	(308, 3),
	(401, 1),
	(401, 3),
	(401, 4),
	(401, 5),
	(401, 6),
	(401, 7),
	(402, 1),
	(402, 3),
	(402, 4),
	(402, 5),
	(402, 6),
	(402, 7);
	
-- delete Jeremiah Reservation
DELETE
FROM Reservation
WHERE GuestId = 8;

-- delete Jeremiah Guest
DELETE
FROM Contact
WHERE GuestId = 8;